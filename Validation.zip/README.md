# Netflix GPT

- Create React App
- Configured TailwindCSS
- Header
- Routing of App
- Login Form
- Sign Up
- Form Validation
- UseRef Hook

# Features
- Login / Sign Up
- Browse ( After Auth )
    - Header
    - Main Movie
        - Trailer  in Background
        - Title & Discription
        - MovieSuggestions
            - MovieLists * N 
- NetflixGPT
    - Search Bar
    - Movie Suggestions            